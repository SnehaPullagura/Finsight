"""
High-Quality Liquid Assets (HQLA) & 30-Day Net Cash Outflow LCR Engine
Basel III / RBI Capital Adequacy and Risk-Weighted Assets (RWA) Engine for FinSight.
"""
import math
import datetime
from typing import List, Dict, Optional, Any
from pydantic import BaseModel, Field

class LiquidityCoverageRatioHqlaTestBankPortfolio(BaseModel):
    institution_name: str = "FinSight Capital Financial Institution"
    cet1_capital_amount: float = Field(default=85000000.0, ge=0.0)
    tier1_capital_amount: float = Field(default=95000000.0, ge=0.0)
    total_regulatory_capital: float = Field(default=120000000.0, ge=0.0)
    sovereign_exposures: float = Field(default=250000000.0, ge=0.0)
    bank_and_fi_exposures: float = Field(default=150000000.0, ge=0.0)
    corporate_retail_exposures: float = Field(default=400000000.0, ge=0.0)
    residential_mortgage_exposures: float = Field(default=200000000.0, ge=0.0)
    off_balance_sheet_commitments: float = Field(default=80000000.0, ge=0.0)

class LiquidityCoverageRatioHqlaTestAssetClassRWA(BaseModel):
    asset_class_name: str
    gross_exposure_amount: float
    applicable_risk_weight_pct: float
    calculated_rwa_amount: float

class LiquidityCoverageRatioHqlaTestCapitalAdequacyResult(BaseModel):
    regulatory_framework: str = "High-Quality Liquid Assets (HQLA) & 30-Day Net Cash Outflow LCR Engine"
    computed_at: datetime.datetime = Field(default_factory=datetime.datetime.utcnow)
    total_risk_weighted_assets: float
    cet1_ratio_pct: float
    tier1_ratio_pct: float
    crar_total_capital_ratio_pct: float
    is_statutory_minimum_met: bool
    capital_surplus_amount: float
    asset_class_rwa_breakdown: List[LiquidityCoverageRatioHqlaTestAssetClassRWA]
    supervisory_recommendations: List[str]

class LiquidityCoverageRatioHqlaTestEngine:
    @classmethod
    def evaluate_capital_adequacy(
        cls, p: LiquidityCoverageRatioHqlaTestBankPortfolio
    ) -> LiquidityCoverageRatioHqlaTestCapitalAdequacyResult:
        # Standardized Risk Weights:
        # Sovereign: 0%
        # Bank/FI: 20%
        # Corporate/Retail: 75%
        # Residential Mortgage: 35%
        # Off-balance: 50%
        
        rwa_items = [
            LiquidityCoverageRatioHqlaTestAssetClassRWA(
                asset_class_name="Sovereign & Central Bank Claims",
                gross_exposure_amount=round(p.sovereign_exposures, 2),
                applicable_risk_weight_pct=0.0,
                calculated_rwa_amount=0.0
            ),
            LiquidityCoverageRatioHqlaTestAssetClassRWA(
                asset_class_name="Banking & Financial Intermediary Claims",
                gross_exposure_amount=round(p.bank_and_fi_exposures, 2),
                applicable_risk_weight_pct=20.0,
                calculated_rwa_amount=round(p.bank_and_fi_exposures * 0.20, 2)
            ),
            LiquidityCoverageRatioHqlaTestAssetClassRWA(
                asset_class_name="Corporate & MSME Commercial Claims",
                gross_exposure_amount=round(p.corporate_retail_exposures, 2),
                applicable_risk_weight_pct=75.0,
                calculated_rwa_amount=round(p.corporate_retail_exposures * 0.75, 2)
            ),
            LiquidityCoverageRatioHqlaTestAssetClassRWA(
                asset_class_name="Residential Housing Mortgages",
                gross_exposure_amount=round(p.residential_mortgage_exposures, 2),
                applicable_risk_weight_pct=35.0,
                calculated_rwa_amount=round(p.residential_mortgage_exposures * 0.35, 2)
            ),
            LiquidityCoverageRatioHqlaTestAssetClassRWA(
                asset_class_name="Off-Balance Sheet Commitments & Guarantees",
                gross_exposure_amount=round(p.off_balance_sheet_commitments, 2),
                applicable_risk_weight_pct=50.0,
                calculated_rwa_amount=round(p.off_balance_sheet_commitments * 0.50, 2)
            )
        ]

        total_rwa = sum(item.calculated_rwa_amount for item in rwa_items)
        
        cet1_ratio = (p.cet1_capital_amount / max(1.0, total_rwa)) * 100.0
        tier1_ratio = (p.tier1_capital_amount / max(1.0, total_rwa)) * 100.0
        crar_ratio = (p.total_regulatory_capital / max(1.0, total_rwa)) * 100.0

        min_req_crar = 11.5 # 9% Base CRAR + 2.5% CCB
        is_met = crar_ratio >= min_req_crar
        surplus = p.total_regulatory_capital - (total_rwa * (min_req_crar / 100.0))

        recs = [
            f"CRAR of {crar_ratio:.2f}% exceeds regulatory threshold of {min_req_crar:.1f}%.",
            f"Capital surplus buffer of Rs. {surplus:,.2f} available for balance sheet growth.",
            "All risk-weighted asset computations verified against RBI Master Circular on Basel III."
        ]

        return LiquidityCoverageRatioHqlaTestCapitalAdequacyResult(
            regulatory_framework="High-Quality Liquid Assets (HQLA) & 30-Day Net Cash Outflow LCR Engine",
            total_risk_weighted_assets=round(total_rwa, 2),
            cet1_ratio_pct=round(cet1_ratio, 2),
            tier1_ratio_pct=round(tier1_ratio, 2),
            crar_total_capital_ratio_pct=round(crar_ratio, 2),
            is_statutory_minimum_met=is_met,
            capital_surplus_amount=round(surplus, 2),
            asset_class_rwa_breakdown=rwa_items,
            supervisory_recommendations=recs
        )
