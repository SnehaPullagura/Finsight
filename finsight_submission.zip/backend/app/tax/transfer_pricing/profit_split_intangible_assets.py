"""
Residual Profit Split Method (RPSM) for High-Value Intangibles
International Transfer Pricing & OECD BEPS Compliance Engine for FinSight.
"""
import math
import datetime
from typing import List, Dict, Optional, Any
from pydantic import BaseModel, Field

class ProfitSplitIntangibleAssetsTransactionInput(BaseModel):
    transaction_reference: str = "TP-TX-9001"
    tested_party_entity_name: str = "FinSight Technologies India Pvt Ltd"
    associated_enterprise_name: str = "FinSight Inc USA"
    operating_revenue: float = Field(default=85000000.0, ge=0.0)
    operating_expenses: float = Field(default=72000000.0, ge=0.0)
    industry_benchmark_pli_median_pct: float = Field(default=16.5, ge=0.0)
    arm_length_range_35th_percentile_pct: float = Field(default=14.2, ge=0.0)
    arm_length_range_65th_percentile_pct: float = Field(default=18.8, ge=0.0)

class ProfitSplitIntangibleAssetsBenchmarkItem(BaseModel):
    company_name: str
    operating_profit_margin_pct: float
    is_in_arms_length_range: bool

class ProfitSplitIntangibleAssetsDeterminationResult(BaseModel):
    methodology_name: str = "Residual Profit Split Method (RPSM) for High-Value Intangibles"
    computed_at: datetime.datetime = Field(default_factory=datetime.datetime.utcnow)
    tested_party_actual_markup_pct: float
    arms_length_median_markup_pct: float
    is_arms_length_compliant: bool
    transfer_pricing_adjustment_required: float
    primary_adjustment_tax_impact: float
    comparable_set: List[ProfitSplitIntangibleAssetsBenchmarkItem]
    statutory_citations: List[str]

class ProfitSplitIntangibleAssetsEngine:
    @classmethod
    def evaluate_arms_length(
        cls, inp: ProfitSplitIntangibleAssetsTransactionInput
    ) -> ProfitSplitIntangibleAssetsDeterminationResult:
        actual_profit = inp.operating_revenue - inp.operating_expenses
        actual_markup = (actual_profit / inp.operating_expenses * 100.0) if inp.operating_expenses > 0 else 0.0

        is_compliant = (actual_markup >= inp.arm_length_range_35th_percentile_pct)

        adj_required = 0.0
        tax_impact = 0.0
        if not is_compliant:
            target_rev = inp.operating_expenses * (1.0 + (inp.industry_benchmark_pli_median_pct / 100.0))
            adj_required = max(0.0, target_rev - inp.operating_revenue)
            tax_impact = adj_required * 0.2517 # 25.17% corporate tax rate

        comparables = [
            ProfitSplitIntangibleAssetsBenchmarkItem(company_name="TechServices Alpha Ltd", operating_profit_margin_pct=15.4, is_in_arms_length_range=True),
            ProfitSplitIntangibleAssetsBenchmarkItem(company_name="DataSolutions Beta Ltd", operating_profit_margin_pct=17.2, is_in_arms_length_range=True),
            ProfitSplitIntangibleAssetsBenchmarkItem(company_name="Global Systems Gamma Ltd", operating_profit_margin_pct=18.1, is_in_arms_length_range=True),
            ProfitSplitIntangibleAssetsBenchmarkItem(company_name="Software Dynamics Delta Ltd", operating_profit_margin_pct=14.8, is_in_arms_length_range=True)
        ]

        return ProfitSplitIntangibleAssetsDeterminationResult(
            tested_party_actual_markup_pct=round(actual_markup, 2),
            arms_length_median_markup_pct=inp.industry_benchmark_pli_median_pct,
            is_arms_length_compliant=is_compliant,
            transfer_pricing_adjustment_required=round(adj_required, 2),
            primary_adjustment_tax_impact=round(tax_impact, 2),
            comparable_set=comparables,
            statutory_citations=[
                "Section 92C of the Income Tax Act 1961",
                "Rule 10B & 10CA of the Income Tax Rules 1962",
                "OECD Transfer Pricing Guidelines for Multinational Enterprises"
            ]
        )
